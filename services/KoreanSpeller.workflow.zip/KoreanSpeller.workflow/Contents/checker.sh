#!/bin/zsh
INPUT_TEXT=$(tee)
BASE_URL=https://speller.cs.pusan.ac.kr
CHECK_URL=$BASE_URL/results
KSC_PATH="$(pwd)/Library/Services/KoreanSpeller.workflow/Contents"
SCRIPT_PATH=$KSC_PATH/script.js
STYLE_PATH=$KSC_PATH/style.css
UPDATE=2020-05-13
UPDATE_STATUS="Current"
#UPDATE_STATUS=$(curl -s -o /dev/null -I -w "%{http_code}" -m 3 https://appletree.or.kr/automator/$UPDATE.txt)
curl --data-urlencode "text1=$INPUT_TEXT" $CHECK_URL -o ~/.cache/korean-spelling-checker-result.html && sed -i -e "s|\.\./|$BASE_URL/|g" ~/.cache/korean-spelling-checker-result.html && sed -E -i -e "s (css|js)/ $BASE_URL/\1/ g" ~/.cache/korean-spelling-checker-result.html && sed -i -e "s|<body|<link rel='stylesheet' href='$STYLE_PATH'><script defer src='$SCRIPT_PATH' id='ksc' data-update-status='$UPDATE_STATUS'></script><base href='$BASE_URL'></head><body|" ~/.cache/korean-spelling-checker-result.html && echo "$(<~/.cache/korean-spelling-checker-result.html)"
